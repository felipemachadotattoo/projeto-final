from django.contrib import admin
from django.urls import path, include
from .views import home, sobre, book, menu

urlpatterns = [
    path('index.html', home),
    path('about.html', sobre),
    path('book.html', book),
    path("menu.html", menu)
]
